library(testthat)
library(SLEMI)

test_check("SLEMI")
