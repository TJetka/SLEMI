# SLEMI 1.0.1

* Added a `NEWS.md` file to track changes to the package.
* Moved the home repository to github.com/TJetka (from github.com/sysbiosig)
* Fixed the bug related to the new version of dependency: ggplot2 (stat_summary function)
* Added unit tests for package maintenance

---

# SLEMI 1.0.0

* Initial CRAN submission